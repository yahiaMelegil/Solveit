<?php echo e($slot); ?>

<?php /**PATH D:\Solvit-backend\solveit-backend-complete-auth-verification-rbac (1)\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>